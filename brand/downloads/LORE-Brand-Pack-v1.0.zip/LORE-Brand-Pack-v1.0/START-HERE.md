# LORE — approved brand pack

Revision LORE-04-v1.0 / 04 — Rising Strokes.

Open brand/README.md for the branding page and brand/assets/README.md for the file catalogue.

PNG files are in brand/assets/png and vector SVGs in brand/assets/svg. The brand guide is in brand/previews. The approved component source, export scripts, hashes and QA records are included. The five social/app PNGs intentionally have backgrounds; all other core PNGs use transparency.

# LORE — Mt. Gox — Epic — Review v3

The approved Locked Out composition is retained with slightly stronger rainfall and wet reflections. The MT. GOX title now appears on one visible line. The assembled card layout is a review candidate.

The PNG and editable SVG use the existing LORE-FRONT-v4 Epic template. Run python build_review.py to rebuild and validate the template, artwork hash, text fields and QR. This package contains the deterministic master export.

Card: 900 × 1260 pixels, intended trim 63 × 88 mm. Date: 28 FEB 2014. Caption: WITHDRAWALS SUSPENDED. QR is an example.com placeholder. Not print-ready.

Artwork source: weather refinement generated from the approved Locked Out composition. The complete edit prompt is included.

The original HODL and Birth of Doge style references are included. This weather refinement and card review have not been approved or published to GitHub. Commercial IP clearance has not been established. MT. GOX appears as custom illustrated lettering in an imagined scene.

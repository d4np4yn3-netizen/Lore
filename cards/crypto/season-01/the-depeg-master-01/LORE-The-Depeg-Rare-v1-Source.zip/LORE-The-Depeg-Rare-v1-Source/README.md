# The Depeg — Rare / final v1

09 MAY 2022 · TERRA / LUNA · STEADY LADS.

Built under Dan's instruction: “ok, make the full card and approved for upload to github”.
Latest splash/cable artwork retained, two selected logos removed and upper emblem kept.
Faint LUNA lettering was removed again to complete the earlier instruction.
ANCHOR / UP TO 20% and the UST/$1 broken tether are unchanged.

Run `python3 build_card.py` to recreate the PNG/SVG with the supplied template, fonts and exact art.
The raster artwork is separate; SVG text and frame are editable.
Both HODL and Birth of Doge were direct inputs to the final ImageGen correction.
The full prompt and references are included.

QR remains a demo placeholder; physical trim is 63 × 88 mm and visual master is 900 × 1260 px.
This is an approved design archive, not a print release.

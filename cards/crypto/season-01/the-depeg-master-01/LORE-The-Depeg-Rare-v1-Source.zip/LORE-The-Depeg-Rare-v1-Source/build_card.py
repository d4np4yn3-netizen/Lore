from pathlib import Path
import base64
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from PIL import Image
import zxingcpp

ROOT = Path(__file__).resolve().parent
MASTER = ROOT / 'support/cards/master/front-v4'
sys.path.insert(0, str(MASTER / 'source'))
import render_card


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def structural(path):
    root = ET.parse(path).getroot()
    for n in root.iter():
        ident = n.get('id')
        if ident == 'card-illustration':
            n.attrib.pop('{http://www.w3.org/1999/xlink}href', None)
        elif ident == 'moment-qr':
            n.attrib.pop('viewBox', None)
            for child in list(n):
                n.remove(child)
        elif ident in render_card.FIELDS:
            n.text = 'CONTENT'
    return ET.tostring(root)


def build():
    data = json.loads((ROOT / 'card-data.json').read_text())
    refs = json.loads((ROOT / 'reference-sources.json').read_text())
    for ref in refs['required_style_references']:
        assert sha(ROOT / ref['local_path']) == ref['sha256'], ref['id']
    svg = ROOT / 'LORE-The-Depeg-Rare-v1.svg'
    render_card.render(dict(data, artwork=str(ROOT / 'art.png')), svg, demo=True)
    png = svg.with_suffix('.png')
    assert Image.open(png).size == (900, 1260)
    assert structural(MASTER / 'templates/rare.svg') == structural(svg), 'Template structure changed'
    nodes = {n.get('id'): n for n in ET.parse(svg).getroot().iter() if n.get('id')}
    assert base64.b64decode(nodes['card-illustration'].get('{http://www.w3.org/1999/xlink}href').split(',', 1)[1]) == (ROOT / 'art.png').read_bytes()
    assert any(code.text == data['qr_url'] for code in zxingcpp.read_barcodes(Image.open(png))), 'QR mismatch'
    for node, key in render_card.FIELDS.items():
        assert nodes[node].text == data[key]
    files = [p for p in ROOT.rglob('*') if p.is_file() and p.name != 'manifest.json' and '__pycache__' not in p.parts]
    manifest = {
        'status': 'USER_APPROVED_FOR_FINAL_ASSEMBLY_AND_GITHUB',
        'dimensions_px': [900, 1260],
        'physical_trim_mm': [63, 88],
        'layout': 'LORE-FRONT-v4',
        'fixed_template_structure_verified': True,
        'art_bytes_preserved': True,
        'art_translation': None,
        'qr_payload': data['qr_url'],
        'qr_status': 'DEMO_ONLY',
        'qr_decode_verified': True,
        'print_release': False,
        'publication_approved': True,
        'reference_policy': 'LORE-CRYPTO-STYLE-v1.1',
        'both_required_style_hashes_verified': True,
        'source_commit': 'e29664e6f8c192a6393312723b145bc7895ef6c9',
        'files': {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(files)}
    }
    (ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'png': str(png), 'svg': str(svg), 'template_verified': True, 'qr_verified': True, 'png_sha256': sha(png), 'art_sha256': sha(ROOT / 'art.png')}))


if __name__ == '__main__':
    build()

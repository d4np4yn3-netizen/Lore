# BitConnect — Rare Review-v3

Uses the exact full artwork matching Dan's attached pyramid crop: the larger
cracked pyramid beside the microphone arm. Dark blue-and-gold lighting and the
corrected sports car are retained. No illustration regeneration or repainting.

The Rare front-v4 layout, fonts, logo, date and copy remain unchanged. PNG preview
and editable SVG included; artwork is raster, text/frame are vector. Review only.
QR is a placeholder. Physical trim 63 × 88 mm requires separate print preparation.

Install requirements.txt and Inkscape, then run python3 build_review.py. The build
checks template geometry, exact art bytes, both style reference hashes, text fields,
900 × 1260 dimensions, and actual QR decoding. Previous versions are preserved.

## Single-word title correction

Dan requested BITCONNECT as one word. Set the first title line to BITCONNECT
and leave the second line empty. At the pinned 70-unit font its measured width
is 502.125 units and right edge 556.125, within the 620-unit limit. No font resize
or element relocation. Bundled renderer has one narrow opt-in change to permit
an empty second title line when single_line_title is true.

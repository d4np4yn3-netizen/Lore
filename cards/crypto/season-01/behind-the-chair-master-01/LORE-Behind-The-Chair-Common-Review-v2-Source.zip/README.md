# LORE — Behind the Chair, Common review v2

Wider scene, lowered NO SIGNS notice and lettering matched to Dan's sign reference. The Common frame and card copy are unchanged from review v1. Desk-note Easter eggs now clear the title.

Open LORE-Behind-The-Chair-Common-Review-v2.png. The SVG embeds the revised art and exact locked logo. card-data.json holds editable fields. art.png is the revised generation. references/ contains the earlier artwork, user sign reference and both mandatory style references; generation-prompt.txt records the full edit request.

Rebuild: install requirements.txt, ensure Inkscape is on PATH, then run python3 build_review.py. Pinned fonts and Common template are bundled.

This revision awaits visual approval. QR is a placeholder; no GitHub upload or print release is claimed.

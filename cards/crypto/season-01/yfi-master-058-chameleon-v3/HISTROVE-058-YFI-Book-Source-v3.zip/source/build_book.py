"""Reproduce the YFI 058 book with its approved v3 illustration.

The compact layout template is derived from the original published book at
commit 1ef8ea3d323fc9bfe3359d95a803f2d48882a900. Its page content streams,
fonts, links, page geometry and all approved copy are unchanged. Only the
illustration XObject was replaced with a blank placeholder in the template.
This builder replaces that placeholder losslessly with the approved RGB art.
Run: python source/build_book.py from the package directory, or any directory.
"""
from pathlib import Path
import hashlib
import json
import zlib

from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, NumberObject
import fitz

B = Path(__file__).resolve().parent.parent
ART = B / 'art.png'
TEMPLATE = B / 'source/book-layout-template.pdf'
MANIFEST = json.loads((B / 'manifest.json').read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha(ART) == MANIFEST['art']['sha256'], 'Approved art hash mismatch'
assert sha(TEMPLATE) == MANIFEST['layout_template']['sha256'], 'Layout template mismatch'
for path, expected in MANIFEST['content_sha256'].items():
    assert sha(B / path) == expected, f'Approved content changed: {path}'

im = Image.open(ART)
assert im.mode == 'RGB' and list(im.size) == MANIFEST['art']['dimensions_px']
pixels = im.tobytes()
reader = PdfReader(TEMPLATE)
writer = PdfWriter()
writer.clone_document_from_reader(reader)
objects = writer.pages[0]['/Resources']['/XObject']
assert len(objects) == 1
target = next(iter(objects.values())).get_object()
assert target['/Subtype'] == '/Image'
target[NameObject('/Width')] = NumberObject(im.width)
target[NameObject('/Height')] = NumberObject(im.height)
target[NameObject('/BitsPerComponent')] = NumberObject(8)
target[NameObject('/ColorSpace')] = NameObject('/DeviceRGB')
target[NameObject('/Filter')] = NameObject('/FlateDecode')
target.pop('/DecodeParms', None)
target._data = zlib.compress(pixels, 9)
assert target.get_data() == pixels
out = B / 'book/HISTROVE-058-YFI-Book.pdf'
out.parent.mkdir(exist_ok=True)
with out.open('wb') as stream:
    writer.write(stream)

doc = fitz.open(out)
assert len(doc) == 2
assert len(doc[1].get_links()) == 7
imgref = doc[0].get_images(full=True)
assert len(imgref) == 1
assert fitz.Pixmap(doc, imgref[0][0]).samples == pixels
previews = []
for n, page in enumerate(doc, 1):
    pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
    preview = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
    preview.save(B / f'book/book-page-{n}.webp', lossless=True, method=6)
    preview.save(B / f'book/book-page-{n}.png')
    previews.append(preview)
spread = Image.new('RGB', (sum(p.width for p in previews), previews[0].height), 'white')
spread.paste(previews[0], (0, 0))
spread.paste(previews[1], (previews[0].width, 0))
spread.save(B / 'book/book-spread.png')
print(json.dumps({'pdf': str(out.relative_to(B)), 'sha256': sha(out),
                  'pages': len(doc), 'exact_art_pixels': True}, indent=2))

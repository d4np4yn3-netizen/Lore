# YFI 058 companion book

Matching two-page book derivative for approved illustration v3. The exact approved PNG is included as art.png. Story copy, all four clue descriptions, page geometry, fonts, and source links are unchanged from the original book at the commit recorded in manifest.json. The Markdown and 058.json remain byte-identical.

## Reproduce

Install the pinned packages in requirements.txt, then run `python source/build_book.py`. It writes the PDF and two lossless WebP previews to book/. No network access is needed for the build. The template retains the original PDF drawing streams and fonts, with a single blank illustration placeholder.

The builder verifies every input hash and embeds the illustration as lossless RGB pixels. PNG container bytes are preserved in art.png; PDF image XObjects store the decoded RGB samples rather than a PNG file container. No artwork edits or upsampling are performed.

## Scope

The only visible change from the original book is the approved illustration. Old proof-only authorization metadata has not been carried into the delivery source. All factual prose and source links are preserved without new research or wording. Native art is 1060 x 1484 pixels, approximately 128 PPI at A4 fit. Physical print acceptance and rights clearance are not independently established by this technical package.

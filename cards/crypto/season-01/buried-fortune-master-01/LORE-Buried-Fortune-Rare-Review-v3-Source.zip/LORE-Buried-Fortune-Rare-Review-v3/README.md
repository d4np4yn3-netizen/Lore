# LORE — Buried Fortune · Rare · Review v3

Final review files: LORE-Buried-Fortune-Rare-Review-v3.png and its matching SVG. The illustration is art.png.

V3 removes the newspaper and makes the Doge plush much more buried and dirty. Card copy and fixed layout remain identical to v1. references/ contains both prior edit inputs and the two mandatory original style artworks.

Built-in image generation performed the edit; its exact prompt is generation-prompt.txt. Source notes distinguish facts from artistic interpretation.

Rebuild with `python3 build_review.py`. Requires Python, Pillow, qrcode, zxing-cpp and Inkscape. The exact template, fonts and original renderer are bundled in support/. The build verifies style hashes, template structure, artwork bytes, fields, dimensions and demo QR decoding.

Awaiting visual approval. No GitHub upload. Demo QR only; no print release. Value explanation is intended for a future QR story at the user's request.

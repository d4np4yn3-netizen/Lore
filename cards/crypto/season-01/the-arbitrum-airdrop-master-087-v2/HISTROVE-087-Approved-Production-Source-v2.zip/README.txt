HISTROVE approved release files

Approved original close-up tortoise with ARBITRUM AIRDROP / WORTH THE WEIGHT.

Use supplied exact SVG and fontconfig.xml. PDF text is outlined. Preserve approved illustration bytes, crop, canonical frame, typography and QR. No image regeneration. Physical printing requires a separate production proof.

Artwork uses fictional symbolic characters. Brand marks belong to their respective owners. No endorsement or physical-print rights clearance is implied.
